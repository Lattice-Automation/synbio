"""MoClo assembly design process and steps."""

from typing import Dict, List

from Bio.SeqRecord import SeqRecord

from ..assembly import moclo
from ..containers import Container, content_id, Well
from ..design import Design
from ..instructions import Temperature
from ..protocol import Protocol
from ..reagents import Reagent
from ..species import Species
from ..steps import Step, Setup, Pipette, Add, ThermoCycle, Incubate, Move


class MoClo(Step):
    """MoClo assembly.

    Takes the design of a protocol and finds combinations of
    SeqRecords that will circularize into valid plasmids. The plasmids are
    filtered for those that will come together to make valid and new designs.

    Full responsibilities include:
        1. subselecting the input designs that will form valid plasmids
            after digestion with BsaI and BpiI
        2. adding NEB Golden Gate Assembly Mix to the valid designs as Contents for a Container
        3. computing the final plasmid (SeqRecord) after ligation of digested fragments
        4. memoize the sorted enzyme + ids -> SeqRecord from step #3, pass as a
            "mutate" method for the step after ThermoCycle()
        5. add steps to carry out the rest of the assembly (heat shock, incubate, etc)

    Keyword Arguments:
        resistance {str} -- resistance to use in backbone selection (default: {"KanR"}),
            remove all circularizable assemblies missing resistance to this backbone
    """

    assembly_mix = Reagent("assembly-mix")  # has both enzymes plus T4, NEB
    water = Reagent("water")

    def __init__(self, resistance: str = ""):
        super().__init__()

        self.resistance = (
            resistance
        )  # search for this. must be in some SeqRecords features
        self.id_to_well: Dict[str, Container] = {}

    def execute(self, protocol: Protocol):
        """Filter designs to those that will form valid and new MoClo devices.

        Run each MoClo step on the protocol. See:
        https://www.neb.com/protocols/2018/10/02/golden-gate-assembly-protocol-for-using-neb-golden-gate-assembly-mix-e1601

        Arguments:
            protocol {Protocol} -- the protocol to add to
        """

        # MoClo must be the first step of a protocol because it uses
        # protocol.design to make assemblies, rather than protocol.containers
        if protocol.steps[0] != self:
            raise RuntimeError("MoClo must be the first step of a protocol.")

        # get all the unique contents and set them up in their own wells
        mixed_wells = self._create_mixed_wells(protocol.design)

        for step in [
            Setup(
                name="Setup PCR plate with (volumes) shown",
                target=mixed_wells,
                instructions=[
                    "Dilute plasmid DNA to 75 ng/µL in 'water'",
                    "Create 'assembly-mix' from 1:1 T4 Ligase Buffer (10X) and NEB Golden Gate Assembly Mix",
                ],
            ),
            Pipette(
                name="Mix plasmids DNA (2 uL) 'assembly-mix' (4 uL) and 'water' (14 uL)",
                target=mixed_wells,
            ),
            ThermoCycle(
                [
                    Temperature(temp=37, time=3600),
                    Temperature(temp=60, time=300),
                    Temperature(temp=4, time=-1),  # hold at 4 degrees
                ],
                mutate=self.mutate,  # set the SeqRecords
            ),
            Move(name="Move 3 uL from each mixture well to new plate(s)", volume=3.0),
            Add(
                name="Add 10 uL of competent E. coli to each well",
                add=Species("competent_e_coli"),
                volume=10.0,
            ),
            ThermoCycle(name="Heat shock", temps=[Temperature(temp=42, time=30)]),
            Add(
                name="Add 150 uL of SOC media to each well",
                add=Reagent("soc_media"),
                volume=150.0,
            ),
            Incubate(name="Incubate", temp=Temperature(temp=37, time=3600)),
        ]:
            step.execute(protocol)

    def _create_mixed_wells(self, design: Design) -> List[Container]:
        """Return the valid circularizable assemblies.

        Also build up the dictionary for `self.id_to_well`, a map from sorted
        Fragment IDs to the SeqRecord that they will form after digestion and ligation.

        Arguments:
            design {Design} -- the design specification (iterable)

        Returns:
            List[Container] -- list of wells to mix fragments for MoClo
        """

        mixed_wells: List[Container] = []
        for assembly in moclo(design, resistance=self.resistance):
            # 2 uL of each plasmid + 4 uL of assembly mix
            volumes = [2.0] * len(assembly) + [4.0]
            volume_water = 20.0 - sum(volumes)
            volumes.append(max(volume_water, 0.0))

            # create a well that mixes the assembly mix, plasmids, and reagents
            well = Well(assembly + [self.assembly_mix, self.water], volumes=volumes)

            self.id_to_well[str(well.id)] = well  # used in self.mutate
            mixed_wells.append(well)

        if not mixed_wells:
            raise RuntimeError(f"Failed to create any MoClo assemblies")

        return sorted(mixed_wells)

    def mutate(self, well: Container) -> Container:
        """Given the contents of a well, return single SeqRecord after digest/ligation."""

        well_id = str(well.id)
        if well_id not in self.id_to_well:
            raise KeyError(f"{well_id} not recognized as a MoClo assembly")

        # create hew new composite SeqRecord after digestion/ligation
        records = [c for c in well if isinstance(c, SeqRecord)]
        record_ids = [content_id(r) for r in records]
        record_combined = records[0].upper()
        for other_record in records[1:]:
            record_combined += other_record.upper()
        record_combined.id = "|".join(record_ids)

        # return a new well with the new combined SeqRecord
        return well.create([record_combined])
