# synbio

`synbio` is a library for designing and assembling DNA. Users can design plasmids or libraries and export multi-step build protocols

## Installation

```bash
pip3 install synbio
```

## Models

Designed to have a minimal API, only a few objects are exposed to the user. `synbio` only expects the user to define their `Design` and `Protocol` (list of steps).

- `SeqRecord` - [BioPython](https://biopython.org/)
- `Design`
  - `Plasmid` - single list of SeqRecords to concatenate
  - `Combinatorial` - list of bins for combinatorial assembly

## Example

In the example below, the user specifies a combinatorial library design. Each list (`record_bin`) appended to the design is another bin of `SeqRecords` to try concatenating with all other `SeqRecords` in adjacent bins.

Behind the scenes, `synbio` is filtering all combinations of `SeqRecords` from the design that will circularize into valid plasmids (via [circuits in a graph](https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-015-0544-x/figures/1)). After running the `protocol`, users can export plate maps (`to_csv()`), composite plasmids (`to_fasta()`, `to_genbank()`), and assembly instructions (`to_txt()`).

```python
"""Example of a Combinatorial MoClo assembly with steps and output."""

from Bio.SeqIO import parse

from synbio import Protocol
from synbio.composite import MoClo
from synbio.design import Combinatorial

# create a combinatorial library design from multiple "bins"
design = Combinatorial()
records = parse("./moclo_parts.fa", "fasta")
for type in ["promoter", "RBS", "CDS", "terminator"]:
    record_bin = [r for r in records if any(f.type == type for f in r.features)]
    design.append(record_bin)  # add a new cominatorial bin

# create a protocol using MoClo as the sole composite step and run
protocol = Protocol(name="Combinatorial MoClo", design=design)
protocol.add(MoClo())
protocol.run()

# export all the output plasmids to a multi-FASTA
protocol.to_fasta("composite_parts.fasta")

# export plate layouts
protocol.to_csv("combinatorial_moclo.csv")

# export protocol
protocol.to_txt("combinatorial_moclo.txt")
```

_composite_parts.fasta_

```txt
>J23100_AB|B0032m_BC|C0012m_CD|B0015_DE|DVK_AE
GGAGTTGACGGCTAGCTCAGTCCTAGGTACAGTGCTAGCTACTAGAGTCACACAGGAAAG
TACTAAATGATGGTGAATGTGAAACCAGTAACGTTATACGATGTCGCAGAGTATGCCGGT
...
```

_combinatorial_moclo.csv_

```csv
Setup PCR plate with (volumes) shown:
Plate 1,1,2,3,4,5,6,7,8,9,10,11,12
A,B0015_DE (4),C0080_CD (18),R0010_AB (54),water (36)
B,B0015_DE (160),DVK_AE (160),cre_CD (18),water (156)
...
```

_combinatorial_moclo.txt_

```txt
Combinatorial MoClo
1. Setup PCR plate with (volumes) shown:
	1.1. Dilute plasmid DNA to 75 ng/µL in 'water'
	1.2. Create 'assembly-mix' from 1:1 T4 Ligase Buffer (10X) and NEB Golden Gate Assembly Mix
...
```
