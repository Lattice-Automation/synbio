"""Assembly methods for piecing together SeqRecords."""

from .restriction import simulate
from .restriction import moclo
