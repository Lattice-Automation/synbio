"""Assembly methods for piecing together SeqRecords."""

from .moclo import moclo
